gapminder_plot <- ggplot(
  data = gapminder07,
  mapping = aes(
    x = gdp_per_capita,
    y = life_expectancy,
    label = country)) + 
  scale_x_log10(labels = scales::dollar) + # labels argument adds $ signs
  geom_point(aes(size = population, 
    fill = continent), 
    shape = 21, 
    color = "white", 
    alpha = 0.8) +
  scale_fill_brewer(palette = "Set2") + # uses palette from Rcolorbrewer package
  scale_size(range = c(1, 20)) +
  labs(title = "Relationship between life expectancy and income, 2007",
    x = "GDP per capita (USD)",
    y = "Life expectency (years)",
    fill = "continent") +
  guides(size = "none") + # removes size legend
  theme_bw() # lighter theme
gapminder_plot
